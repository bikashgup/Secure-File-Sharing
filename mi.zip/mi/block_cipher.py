import sys

class block_cipher:
    
    def _init_(self):
        pass
    
    
